/*
 * Descripción: mostrar Hola mundo al usuario
 * Autor: José Abril
 * Fecha: 19/09/25
 */

package holaMundo;

public class HolaMundo {

	public static void main(String[] args) {
		
		System.out.println("Hola, mundo");
		
		System.out.println("Mi primer programa Java");
		
	}

}
