package escribirnombre;

public class Escribirnombre {

	public static void main(String[] args) {

		System.out.println("José Abril García");
		
	}

}