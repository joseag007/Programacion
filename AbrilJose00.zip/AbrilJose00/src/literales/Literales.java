package literales;

public class Literales {

	public static void main(String[] args) {
		
		int edad_niño = 12;
				
		final double velocidad_luz = 300000;
		
		final int edad_minima = 10;
		
		String mail = "vaya@mail.com";
		
		double peso_atleta = 40.44;
		
		final int meses_año = 12;
		
		char letra_DNI = 'C';
		
		String telefono = "887-44-42-12";
		
		final long DISTANCIA_TIERRA_SOL = 147_100_000_000L;
		
		final double KM_RECORRIDOS_LUZ_AÑO = 9_460_740_478_580.8d;

	}

}
