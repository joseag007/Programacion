/*
 * Descripción: media y número de ceros
 * Autor: José Abril
 * Fecha: 14/10/25
 */

package ejercicio4;

import java.util.Scanner;

public class Ejercicio4 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		
		int contador =0;
		int suma =0;
		
		System.out.println("Introduzca un valor: ");
        int num = teclado.nextInt();
		
			while (num > 0) {
				
		        contador++;
		        suma = suma + num;
		        
		        System.out.println("Introduzca un valor: ");
		        num = teclado.nextInt();
			}
		
		System.out.println( "La cantidad de números mayores que cero introducidos es de: " + contador);
		System.out.println("La media de los números registrados es de: " + suma/contador);
		
		
	}
}
