/*
* Descripción: ejercicio con tipos de variables.
* Autor: José
* Fecha: 25/09/2025
*/
package ejercicio4;

public class Ejercicio4 {

	public static void main(String[] args) {
		
			byte var1 = 125; //Declaración e inicialización
			short var2 = 397; //Declaración e inicialización
	        int var3 = 1234; //Declaración e inicialización
	        char var4 = 'C'; //Declaración e inicialización
	        double var5 = 3.123456789; //Declaración e inicialización
	        float var6 = 3.89f; //Declaración e inicialización
	        String var7 = "Hola, soy José"; //Declaración e inicialización
	        
	        System.out.println("El valor de la variable tipo byte es: " + var1);
	        System.out.println("El valor de la variable tipo short es: " + var2);
	        System.out.println("El valor de la variable tipo entera es: " + var3);
	        System.out.println("El valor de la variable tipo carácter es: " + var4);
	        System.out.println("El valor de la variable tipo decimal es: " + var5);
	        System.out.println("El valor de la variable tipo flotante es: " + var6);
	        System.out.println("El valor de la variable tipo cadena de caracteres es: " + var7);

	}

}