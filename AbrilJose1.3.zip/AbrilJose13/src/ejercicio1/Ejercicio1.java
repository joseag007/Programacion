/*
* Descripción: Calculo de salario
* Autor: José
* Fecha: 30/09/2025
*/
package ejercicio1;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		String nombre;
		System.out.print("Introduzca su nombre: ");
		nombre = teclado.nextLine(); // petición del nombre
		
		String apellidos;
		System.out.print("Introduzca sus apellidos: ");
		apellidos = teclado.nextLine(); // petición de los apellidos
		
		int añoNacimiento;
		System.out.print("Introduzca el año en el que nació: ");
		añoNacimiento = teclado.nextInt(); // petición del año de nacimiento
		
		double salarioBruto;
		System.out.print("Introduzca su salario bruto: ");
		salarioBruto = teclado.nextDouble(); // petición del salario bruto
		
		int añosTrabajados;
		System.out.print("Introduzca la cantidad de años trabajados en la empresa: ");
		añosTrabajados = teclado.nextInt(); // petición de años trabajados
		
		double salarioNeto = salarioBruto - salarioBruto * 15/100; // calculo del salario neto
		double aumento = salarioBruto * 2/100 * añosTrabajados; // calculo del aumento en funcion de los años trabajados
		double salarioTotal = salarioNeto +aumento; // calculo del salario total
		
		System.out.println("Estimad@ "+nombre + " "+ apellidos + ", su salario bruto es "+salarioBruto+", teniendo en cuenta un IRPF del 15% su salario neto es " + salarioNeto + ".");
		System.out.println("Debido a sus " + añosTrabajados + " años trabajando en la empresa su salario se incrementará en un 2% por cada año. El aumento es de " + aumento+" y el salario total es "+salarioTotal+"." );
		
	}

}
