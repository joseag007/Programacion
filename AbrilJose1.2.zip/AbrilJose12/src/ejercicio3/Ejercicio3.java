/*
* Descripción: petición informacion equipo
* Autor: José
* Fecha: 25/09/2025
*/
package ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		int num1 = 1, num2 = 1; //Declaración e inicialización
		char char1 = 'A', char2 = 'B'; //Declaración e inicialización
		String cargo = "Estudiante", nombre = "José"; //Declaración e inicialización
		
		System.out.println("Este es el valor del primer número: " + num1); // mostrar num1
		System.out.println("Este es el valor del segundo número: " + num2); // mostrar num2
		
		System.out.println("Bienvenido, " + cargo +" "+ nombre); // mostrar cargo nombre
		
	}

}
