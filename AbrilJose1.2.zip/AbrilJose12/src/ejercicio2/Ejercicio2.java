/*
* Descripción: petición informacion equipo
* Autor: José
* Fecha: 25/09/2025
*/
package ejercicio2;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		String nombreEquipo;
		System.out.print("Introduzca el nombre del equipo: ");
		nombreEquipo = teclado.nextLine(); // petición del nombre del equipo
		
		int añoDeFundacion;
		System.out.print("Introduzca el año en el que se fundo: ");
		añoDeFundacion = teclado.nextInt(); // petición del año de fundación
		
		teclado.nextLine();
		String nombreEstadio;
		System.out.print("Introduzca el nombre del estadio: ");
		nombreEstadio = teclado.nextLine(); // petición del nombre del estadio
		
		String nombreCapitan;
		System.out.print("Introduzca el nombre del capitán: ");
		nombreCapitan = teclado.nextLine(); // petición del nombre del capitán
		
		System.out.println("Nombre del Equipo: " + nombreEquipo); // mostrar nombre del equipo
		System.out.println("Fundado en: " + añoDeFundacion); // mostrar año de fundación
		System.out.println("Estadio: " + nombreEstadio); // mostrar nombre del estadio
		System.out.println("Capitán: " + nombreCapitan); // mostrar nombre del capitán

	}

}
